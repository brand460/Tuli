import React, { useState, useRef } from "react";
import { AuthProvider, useAuth } from "./auth-context";
import { AuthScreen } from "./auth-screen";
import { OnboardingScreen } from "./onboarding-screen";
import { MainShell } from "./main-shell";
import { Loader2 } from "lucide-react";
import { supabase } from "./supabase-client";
import { OAuthCallbackHandler } from "./oauth-callback-handler";

// ── Extract deep-link invite token from URL on app load ─────────
function extractInviteFromUrl(): string | null {
  try {
    // Don't extract invite if we're processing OAuth callback
    const params = new URLSearchParams(window.location.search);
    if (params.get("code")) {
      // OAuth callback in progress, skip invite extraction
      return null;
    }

    const token = params.get("invite");
    if (token) {
      // Clean the token from the URL without a page reload
      const clean = window.location.pathname + window.location.hash;
      window.history.replaceState({}, "", clean);
      return token.trim();
    }
    // Also support path format /invite/TOKEN
    const pathMatch = window.location.pathname.match(/\/invite\/([^/]+)/);
    if (pathMatch?.[1]) {
      window.history.replaceState({}, "", "/");
      return pathMatch[1].trim();
    }
  } catch {
    /* ignore */
  }
  return null;
}

// ── Router ─────────────────────────────────────────────────────
function AppRouter() {
  const { session, household, loading, isLoadingHousehold } = useAuth();

  // Capture invite token once on mount; survives auth flow via state
  const [pendingToken] = useState<string | null>(extractInviteFromUrl);

  // Track whether we have ever finished the initial load.
  // Once true, we never show the splash again — even if isLoadingHousehold
  // briefly becomes true on app-resume / token-refresh.
  const hasLoadedOnce = useRef(false);
  if (!loading && !isLoadingHousehold) {
    hasLoadedOnce.current = true;
  }

  // ── Loading splash ─────────────────────────────────────────
  // Show spinner only during the very first auth check, never on resume.
  if ((loading || isLoadingHousehold) && !hasLoadedOnce.current) {
    return (
      <div
        className="flex flex-col items-center justify-center font-sans"
        style={{ height: "100dvh", background: "var(--zu-bg)" }}
      >
        <img
          src="/Tuli-Logo.png"
          alt="Tuli"
          style={{ width: 56, height: 56, borderRadius: 14, marginBottom: 16, objectFit: "cover" }}
        />
        <Loader2 className="w-5 h-5 animate-spin" style={{ color: "var(--text-3)" }} />
      </div>
    );
  }

  // ── Not logged in → Auth screen ───────────────────────────
  if (!session) {
    return <AuthScreen pendingInvite={!!pendingToken} />;
  }

  // ── Logged in but no household → Onboarding ───────────────
  // Only reached when isLoadingHousehold is false, so household === null
  // means the user genuinely has no household (not just "not loaded yet").
  if (!household) {
    return <OnboardingScreen pendingToken={pendingToken} />;
  }

  // ── Logged in + household → App ──────────────────────────
  return <MainShell />;
}

export function AppContent() {
  return (
    <OAuthCallbackHandler>
      <AuthProvider>
        <AppRouter />
      </AuthProvider>
    </OAuthCallbackHandler>
  );
}